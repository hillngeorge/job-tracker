import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000' }); // Ensure this base URL matches your backend URL

export const getJobs = async () => {
  try {
    const response = await API.get('/jobs'); // Ensure this route exists in the backend
    return response.data;
  } catch (error) {
    console.error('Error fetching jobs:', error);
    throw error;
  }
};
