import axios from 'axios';

const API_KEYS = {
  linkedin: 'YOUR_LINKEDIN_API_KEY',
  indeed: 'YOUR_INDEED_API_KEY',
  glassdoor: 'YOUR_GLASSDOOR_API_KEY',
};

export const searchJobsOnLinkedIn = async (query) => {
  const response = await axios.get(`https://api.linkedin.com/v2/jobSearch?q=${query}&oauth2_access_token=${API_KEYS.linkedin}`);
  return response.data.jobs;
};

export const searchJobsOnIndeed = async (query) => {
  const response = await axios.get(`https://api.indeed.com/ads/apisearch?publisher=${API_KEYS.indeed}&q=${query}`);
  return response.data.results;
};

export const searchJobsOnGlassdoor = async (query) => {
  const response = await axios.get(`https://api.glassdoor.com/api/api.htm?t.p=${API_KEYS.glassdoor}&q=${query}`);
  return response.data.response.jobs;
};
