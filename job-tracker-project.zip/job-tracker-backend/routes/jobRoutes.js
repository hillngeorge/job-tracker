const express = require('express');
const router = express.Router();
const Job = require('../models/job'); // Assuming you have a Job model

// GET /jobs - Fetch all jobs
router.get('/jobs', async (req, res) => {
  try {
    const jobs = await Job.find(); // Fetch jobs from the database
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
