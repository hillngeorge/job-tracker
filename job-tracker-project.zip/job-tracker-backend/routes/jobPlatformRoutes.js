const express = require('express');
const { searchJobsOnLinkedIn, searchJobsOnIndeed, searchJobsOnGlassdoor } = require('../services/jobPlatformAPI');
const router = express.Router();

router.get('/search/linkedin', async (req, res) => {
  const jobs = await searchJobsOnLinkedIn(req.query.q);
  res.json(jobs);
});

router.get('/search/indeed', async (req, res) => {
  const jobs = await searchJobsOnIndeed(req.query.q);
  res.json(jobs);
});

router.get('/search/glassdoor', async (req, res) => {
  const jobs = await searchJobsOnGlassdoor(req.query.q);
  res.json(jobs);
});

module.exports = router;
