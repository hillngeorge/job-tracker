const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
  company: String,
  position: String,
  applicationDate: Date,
  status: { type: String, default: 'Applied' },
});

module.exports = mongoose.model('Job', jobSchema);
