import React, { useState, useEffect } from 'react';
import JobForm from '../components/JobForm';
import JobList from '../components/JobList';
import SearchBar from '../components/SearchBar';
import { getJobs, addJob, deleteJob, updateJob } from '../services/jobService'; // Fix this path if needed

const Dashboard = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    const fetchedJobs = await getJobs();
    setJobs(fetchedJobs);
  };

  const handleAddJob = async (jobData) => {
    await addJob(jobData);
    fetchJobs();
  };

  const handleDeleteJob = async (jobId) => {
    await deleteJob(jobId);
    fetchJobs();
  };

  const handleUpdateJob = async (jobId) => {
    await updateJob(jobId);
    fetchJobs();
  };

  const handleSearch = async (query) => {
    // Call job platform APIs with the search query
    // Display results to the user
  };

  return (
    <div className="dashboard">
      <h1>Job Tracker Dashboard</h1>
      <JobForm onAddJob={handleAddJob} />
      <SearchBar onSearch={handleSearch} />
      <JobList jobs={jobs} onDelete={handleDeleteJob} onUpdate={handleUpdateJob} />
    </div>
  );
};

export default Dashboard;
