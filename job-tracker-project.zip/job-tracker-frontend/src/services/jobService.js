import axios from 'axios';

// Create an Axios instance with the backend API base URL
const API = axios.create({ baseURL: 'http://localhost:5000' });

// Fetch all jobs
export const getJobs = async () => {
  try {
    const response = await API.get('/jobs');
    return response.data;
  } catch (error) {
    console.error('Error fetching jobs:', error);
    throw error;
  }
};

// Add a new job
export const addJob = async (jobData) => {
  try {
    const response = await API.post('/jobs', jobData);
    return response.data;
  } catch (error) {
    console.error('Error adding job:', error);
    throw error;
  }
};

// Update a job's status or details
export const updateJob = async (jobId, updatedData) => {
  try {
    const response = await API.put(`/jobs/${jobId}`, updatedData);
    return response.data;
  } catch (error) {
    console.error('Error updating job:', error);
    throw error;
  }
};

// Delete a job
export const deleteJob = async (jobId) => {
  try {
    const response = await API.delete(`/jobs/${jobId}`);
    return response.data;
  } catch (error) {
    console.error('Error deleting job:', error);
    throw error;
  }
};
