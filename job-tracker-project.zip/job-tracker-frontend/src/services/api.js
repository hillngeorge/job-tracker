import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000' });

export const addJob = (jobData) => API.post('/jobs', jobData);
export const getJobs = () => API.get('/jobs');
