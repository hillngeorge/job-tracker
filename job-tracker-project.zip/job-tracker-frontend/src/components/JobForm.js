import React, { useState } from 'react';

const JobForm = ({ onAddJob }) => {
  const [job, setJob] = useState({
    company: '',
    position: '',
    applicationDate: '',
    status: 'Applied',
  });

  const handleChange = (e) => {
    setJob({ ...job, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddJob(job);
    setJob({ company: '', position: '', applicationDate: '', status: 'Applied' });
  };

  return (
    <form onSubmit={handleSubmit} className="job-form">
      <input type="text" name="company" placeholder="Company" value={job.company} onChange={handleChange} required />
      <input type="text" name="position" placeholder="Position" value={job.position} onChange={handleChange} required />
      <input type="date" name="applicationDate" value={job.applicationDate} onChange={handleChange} required />
      <select name="status" value={job.status} onChange={handleChange}>
        <option value="Applied">Applied</option>
        <option value="Interviewing">Interviewing</option>
        <option value="Offered">Offered</option>
        <option value="Rejected">Rejected</option>
      </select>
      <button type="submit">Add Job</button>
    </form>
  );
};

export default JobForm;
