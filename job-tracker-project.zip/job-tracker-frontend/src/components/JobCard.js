import React from 'react';

const JobCard = ({ job, onDelete, onUpdate }) => {
  return (
    <div className="job-card">
      <h3>{job.company}</h3>
      <p>{job.position}</p>
      <p>Applied on: {new Date(job.applicationDate).toLocaleDateString()}</p>
      <p>Status: {job.status}</p>
      <button onClick={() => onUpdate(job._id)}>Update Status</button>
      <button onClick={() => onDelete(job._id)}>Delete Job</button>
    </div>
  );
};

export default JobCard;
