import React from 'react';
import JobCard from './JobCard';

const JobList = ({ jobs, onDelete, onUpdate }) => {
  return (
    <div className="job-list">
      {jobs.map(job => (
        <JobCard key={job._id} job={job} onDelete={onDelete} onUpdate={onUpdate} />
      ))}
    </div>
  );
};

export default JobList;
